function onUpdatePost(elapsed) setProperty('botplayTxt.text', 'TEXT HERE') end
